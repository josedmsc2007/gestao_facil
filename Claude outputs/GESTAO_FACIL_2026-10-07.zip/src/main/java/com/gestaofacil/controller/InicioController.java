package com.gestaofacil.controller;

import com.gestaofacil.security.UsuarioAutenticado;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Telas iniciais depois do login.
 *
 * O REDIRECIONAMENTO POR PERFIL (RN006) MORA AQUI, NUM LUGAR SO
 * Depois de um login bem-sucedido, o Spring Security manda todo mundo para
 * "/" (ver defaultSuccessUrl no SecurityConfig). E o metodo inicio() abaixo
 * que decide o destino. Concentrar a decisao num unico metodo evita que a
 * regra fique espalhada e comecem a divergir.
 *
 * A tela /painel e PROVISORIA: existe para o redirecionamento ter para onde
 * ir e sera substituida pelos cards das proximas funcionalidades. A
 * /lancamentos, do Motorista, deixou de ser provisoria no card #006 e mora
 * no UsoVeiculoController.
 */
@Controller
public class InicioController {

    /**
     * Porta de entrada do sistema para quem ja esta logado.
     *
     * @AuthenticationPrincipal entrega o objeto que guardamos na sessao no
     * momento do login. Como o SecurityConfig exige autenticacao em "/",
     * aqui ele nunca chega nulo.
     */
    @GetMapping("/")
    public String inicio(@AuthenticationPrincipal UsuarioAutenticado logado) {

        // RF07 tem prioridade sobre tudo: senha temporaria nao ve mais nada.
        if (logado.isSenhaTemporaria()) {
            return "redirect:/trocar-senha";
        }

        // RN006: cada perfil comeca na sua tela.
        //
        // Um "switch" com os tres perfis, e nao um if/else que manda "todo o
        // resto" para /lancamentos: foi exatamente assim que o Operador,
        // quando chegou no card #002, teria caido na tela do motorista e
        // levado 403. Com o switch sem "default", o compilador obriga quem
        // acrescentar um perfil ao enum a vir aqui dizer o destino dele.
        return switch (logado.getPerfil()) {
            case OPERADOR -> "redirect:/empresas";
            case ADMINISTRADOR -> "redirect:/painel";
            case MOTORISTA -> "redirect:/lancamentos";
        };
    }

    /** Tela inicial do Administrador. Provisoria. */
    @GetMapping("/painel")
    public String painel(@AuthenticationPrincipal UsuarioAutenticado logado, Model model) {
        model.addAttribute("logado", logado);
        return "painel/painel";
    }
}
